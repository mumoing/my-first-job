
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class parseAll {
	public static List<String> inoreader(String web)throws Exception
	{
		List<String> parse=new ArrayList<String>();
		StringBuffer num=new StringBuffer();
		Document doc=Jsoup.parse(web);
		String title=doc.select("[dir=\"ltr\"]").first().child(0).text();
		//System.out.println(title);
		title=youdao.getTranslate(title);
		parse.add(title);
		num.append(title);
	    Elements duan=doc.select("p");
	    String content="";
	    for(Element e:duan)
	    {
	    	//System.out.println(e.text());
	    	content=youdao.getTranslate(e.text());
	    	parse.add(content);
	    	num.append(content);
	    }
	   String num1=num.toString();
	   num1=Integer.toString(length(num1));
	   parse.add(num1);
	   return parse;
	   
		
    	//return result;
	}
	
	
	public static int length(String value) {  
        int valueLength = 0;  
        String chinese = "[\u0391-\uFFE5]";  
        /* 获取字段值的长度，如果含中文字符，则每个中文字符长度为2，否则为1 */  
        for (int i = 0; i < value.length(); i++) {  
            /* 获取一个字符 */  
            String temp = value.substring(i, i + 1);  
            /* 判断是否为中文字符 */  
            if (temp.matches(chinese)) {  
                /* 中文字符长度为2 */  
                valueLength += 1;  
            }  
        }  
        return valueLength;  
    } 
}
