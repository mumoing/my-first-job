
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

public class word {
	public static void main(String[] args)
	{
		setfolder();
	}
	public static String getdate()
	{
		
		Date d = new Date();  
        SimpleDateFormat sm = new SimpleDateFormat("yyyy-MM-dd");  
        String now = sm.format(d);
        File f=new File(File.separator+"home"+File.separator+"newword"+File.separator+now);
        if(!f.exists())
        {
        	setfolder();
        	return now;
        }
        else{
        	return now;
        }
	}
	public static void setfolder()
	{
		Date d = new Date();  
        SimpleDateFormat sm = new SimpleDateFormat("yyyy-MM-dd");  
        String now = sm.format(d);
       // System.out.println(now);
        File f=new File(File.separator+"home"+File.separator+"newword"+File.separator+now);
        f.mkdirs();
        f=new File(File.separator+"home"+File.separator+"newword"+File.separator+now+File.separator+"0-600");
        f.mkdirs();
        f=new File(File.separator+"home"+File.separator+"newword"+File.separator+now+File.separator+"600-700");
        f.mkdirs();
        f=new File(File.separator+"home"+File.separator+"newword"+File.separator+now+File.separator+"700-800");
        f.mkdirs();
        f=new File(File.separator+"home"+File.separator+"newword"+File.separator+now+File.separator+"800-1300");
        f.mkdirs();
        f=new File(File.separator+"home"+File.separator+"newword"+File.separator+now+File.separator+"1300-1600");
        f.mkdirs();
        f=new File(File.separator+"home"+File.separator+"newword"+File.separator+now+File.separator+"1600-2000");
        f.mkdirs();
        f=new File(File.separator+"home"+File.separator+"newword"+File.separator+now+File.separator+"2000-3000");
        f.mkdirs();
        f=new File(File.separator+"home"+File.separator+"newword"+File.separator+now+File.separator+"3000-");
        f.mkdirs();
	}
	public static void output(List<String> inputs)throws Exception
	{
	  String date=getdate();
	  String title=inputs.get(0);
	  title=title.replaceAll("\"","\'").replaceAll("？", "").replaceAll("[?]", "");
	 
	  String filename=title+".docx";
	  String words=inputs.get(inputs.size()-1);
	  String path=File.separator+"home"+File.separator+"newword"+File.separator+date+File.separator+choose(words);
	  String writepath=path+File.separator+filename;
	  createWord(path,filename);
	  XWPFParagraph[] paragraphs=new XWPFParagraph[inputs.size()-1];
	  XWPFRun[] runs=new XWPFRun[inputs.size()-1];
	  InputStream istream=new FileInputStream(writepath);
      OutputStream ostream= new FileOutputStream(writepath);
	  XWPFDocument document=new XWPFDocument();
	  for(int i=0;i<inputs.size()-1;i++)
	  {
		 
		  paragraphs[i]=document.createParagraph();
		  if(i==0)
		  {
			  paragraphs[i].setAlignment(ParagraphAlignment.CENTER);
			  runs[i]=paragraphs[i].createRun();
			  runs[i].setText(inputs.get(i));
			  runs[i].setFontSize(14);
		  }
		  else{
			  paragraphs[i].setIndentationFirstLine(400);
		      runs[i]=paragraphs[i].createRun();
		      runs[i].setText(inputs.get(i));
		  }	
		  
	  }
	  document.write(ostream);
	  document.close();
	  istream.close();
	  
	  
	}
	public static String choose(String num)
	{
		int words=Integer.parseInt(num);
		if(words>=0&&words<600)
		{
			return "0-600";
		}
		else if(words>=600&&words<700)
		{
			return "600-700";
		}
		else if(words>=700&&words<800)
		{
			return "700-800";
		}
		else if(words>=800&&words<1300)
		{
			return "800-1300";
		}
		else if(words>=1300&&words<=1600)
		{
			return "1300-1600";
		}
		else if(words>1600&&words<2000)
		{
			return "1600-2000";
		}
		else if(words>=2000&&words<3000)
		{
			return "2000-3000";
		}
		else{
			return "3000-";
		}
	}
	
	public static void createWord(String path,String fileName){
        //判断目录是否存在  
         File file=new File(path);
         //exists()测试此抽象路径名表示的文件或目录是否存在。
         //mkdir()创建此抽象路径名指定的目录。
         //mkdirs()创建此抽象路径名指定的目录，包括所有必需但不存在的父目录。
         if(!file.exists()) file.mkdirs();
        //因为HWPFDocument并没有提供公共的构造方法 所以没有办法构造word  
        //这里使用word2007及以上的XWPFDocument来进行构造word  
         @SuppressWarnings("resource")
        XWPFDocument document=new XWPFDocument();
         OutputStream stream=null;
         try {
            stream = new FileOutputStream(new File(file, fileName));
             document.write(stream);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            if(stream != null);
            try {
                stream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
	
}
