
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpEntity;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.apache.http.NameValuePair;

public class youdao {
	public static String getTranslate(String english)throws Exception
	{
		String url="http://m.youdao.com/translate";
		CloseableHttpClient client=HttpClients.createDefault(); //创建一个可关闭的客户端
		HttpPost hp=new HttpPost(url);//创建post方法
		//设置头信息
		hp.setHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
		hp.setHeader("Accept-Encoding", "gzip, deflate");
		hp.setHeader("Accept-Language","en-us");
		hp.setHeader("Connection","keep-alive");
		hp.setHeader("Content-Type","application/x-www-form-urlencoded");
		hp.setHeader("Cookie"," _yd_btn_fanyi_7=true; _yd_banner_day=7; ___rl__test__cookies=1528350041801; _yd_newbanner_day=7; YOUDAO_MOBILE_ACCESS_TYPE=0; OUTFOX_SEARCH_USER_ID_NCOO=1590110050.438731; OUTFOX_SEARCH_USER_ID=-1450346282@183.162.52.81");
		hp.setHeader("Host","m.youdao.com");
		hp.setHeader("Origin","http://m.youdao.com");
		hp.setHeader("Proxy-Connection","keep-alive");
		hp.setHeader("Referer","http://m.youdao.com/translate?vendor=fanyi.web");
		hp.setHeader("Upgrade-Insecure-Requests","1");
		hp.setHeader("User-Agent","Mozilla/5.0 (iPhone; CPU iPhone OS 11_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.0 Mobile/15E148 Safari/604.1");
		try{
		List<NameValuePair> formParams = new ArrayList<NameValuePair>();
		formParams.add(new BasicNameValuePair("type","auto"));
		formParams.add(new BasicNameValuePair("inputtext", english));
		HttpEntity entity = new UrlEncodedFormEntity(formParams, "UTF-8");
		hp.setEntity(entity); 
		CloseableHttpResponse response=client.execute(hp);
		HttpEntity entitys = response.getEntity();
		String web= EntityUtils.toString(entitys,"UTF-8");
		Document doc=Jsoup.parse(web,"utf-8");
		String result=doc.getElementById("translateResult").child(0).html();
		//System.out.println(result);
		client.close();
		return result;
		}catch(Exception e)
		{
			return "";
		}
		
		
	
	}
}
