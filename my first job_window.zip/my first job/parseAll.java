import java.util.ArrayList;
import java.util.List;


public class parseAll {
	public static List<String> Huffington(String web)throws Exception
	{
		List<String> result=new ArrayList<String>();
		StringBuffer all=new StringBuffer();
    	String[] p=web.split("\r\n\r\n");
    	for(int i=1;i<p.length;i++)
    	{
    		//System.out.println(p[i]);
    		if((i!=2)&&(p[i].indexOf("Shared via Inoreader"))==-1)
    		{
    			p[i]=youdao.getTranslate(p[i]);
    			result.add(p[i]);
    			all.append(p[i]);
    			
    		}
    	}
    	String num=Integer.toString(length(all.toString()));
    	result.add(num);
    	return result;
	}
	
	
	public static int length(String value) {  
        int valueLength = 0;  
        String chinese = "[\u0391-\uFFE5]";  
        /* 获取字段值的长度，如果含中文字符，则每个中文字符长度为2，否则为1 */  
        for (int i = 0; i < value.length(); i++) {  
            /* 获取一个字符 */  
            String temp = value.substring(i, i + 1);  
            /* 判断是否为中文字符 */  
            if (temp.matches(chinese)) {  
                /* 中文字符长度为2 */  
                valueLength += 1;  
            }  
        }  
        return valueLength;  
    } 
}
