
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;     
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.mail.*;      
import javax.mail.internet.*;

public class pine{ 
     public static void main(String args[]) throws Exception {     
            mythread my=new mythread();
            Thread hi=new Thread(my);
            hi.start();
        }
    private MimeMessage mimeMessage = null;      
    private StringBuffer bodytext = new StringBuffer();//存放邮件内容       
    public static final String dbuser="root";
    public static final String dbpass="jizhen";
    public static final String dburl="jdbc:mysql://localhost:3306/job";
    public static final String dbdriver="org.gjt.mm.mysql.Driver";
    public pine(MimeMessage mimeMessage) {       this.mimeMessage = mimeMessage;      }      
    public void setMimeMessage(MimeMessage mimeMessage) {       this.mimeMessage = mimeMessage;      }         
    public String getSubject() throws MessagingException {      
        String subject = "";      
        try {      
            subject = MimeUtility.decodeText(mimeMessage.getSubject());      
            if (subject == null)      
                subject = "";      
        } catch (Exception exce) {}      
        return subject;      
    }      
    public String getMessageId() throws MessagingException {      return mimeMessage.getMessageID();       } 
    public String getBodyText() {         return bodytext.toString();      }   
    
    public void getMailContent(Part part) throws Exception {      
        String contenttype = part.getContentType();      
        int nameindex = contenttype.indexOf("name");      
        boolean conname = false;      
        if (nameindex != -1)      
            conname = true;       
        if (part.isMimeType("text/plain") && !conname) {      
            bodytext.append((String) part.getContent());      
        } else if (part.isMimeType("text/html") && !conname) {      
            //bodytext.append((String) part.getContent());      
        } else if (part.isMimeType("multipart/*")) {      
            Multipart multipart = (Multipart) part.getContent();      
            int counts = multipart.getCount();      
            for (int i = 0; i < counts; i++) {      
                getMailContent(multipart.getBodyPart(i));      
            }      
        } else if (part.isMimeType("message/rfc822")) {      
            getMailContent((Part) part.getContent());      
        } else {}      
    }      
    
    public static void insert(String id)throws Exception
    {
            Class.forName(dbdriver);
            Connection co=DriverManager.getConnection(dburl,dbuser,dbpass);
            String sql="INSERT INTO mail VALUES(?)";
            PreparedStatement pstmt=co.prepareStatement(sql);
            pstmt.setString(1, id);
            pstmt.executeUpdate();
            pstmt.close();
            co.close();
            
    }
    public static boolean find(String id)throws Exception
    {
        Class.forName(dbdriver);
        Connection co=DriverManager.getConnection(dburl,dbuser,dbpass);
        String sql="SELECT* FROM mail WHERE mailid=?";
        PreparedStatement pstmt=co.prepareStatement(sql);
        pstmt.setString(1, id);
        ResultSet rs=pstmt.executeQuery();
        int i=0;
        while(rs.next())
        {
            i++;
        }
        rs.close();
        pstmt.close();
        co.close();
        if(i!=0)
        {
            return false;
        }
        else{
            return true;
        }
        
    }
    
    public static List<String> one_parse()throws Exception{
        List<String> allweb=new ArrayList<String>();
        String pop3Server = "pop.126.com";
        String protocol = "pop3";
        String username = "mumoing@126.com";
        String password = "jizhen123"; // QQ邮箱的SMTP的授权码，什么是授权码，它又是如何设置？
        Properties props = new Properties();
        props.setProperty("mail.transport.protocol", protocol); // 使用的协议（JavaMail规范要求）
        props.setProperty("mail.smtp.host", pop3Server); // 发件人的邮箱的 SMTP服务器地址
        // 获取连接
        Session session = Session.getDefaultInstance(props);
        session.setDebug(false);
        // 获取Store对象
        Store store = session.getStore(protocol);
        store.connect(pop3Server, username, password); // POP3服务器的登陆认证
        Folder folder = store.getFolder("INBOX");// 获得用户的邮件帐户
        folder.open(Folder.READ_WRITE); // 设置对邮件帐户的访问权限
 
        
        Message message[] = folder.getMessages();     
            
        pine pmm = null;     
        for (int i = 0; i < message.length; i++) {   
            String from = message[i].getFrom()[0].toString();// 获得发送者地址
            Pattern  pattern=Pattern.compile("[a-zA-Z0-9_-]+@\\w+\\.[a-z]+(\\.[a-z]+)?");  
            Matcher  ma=pattern.matcher(from); 
            while(ma.find())
            {
             from=ma.group();
            }
            if(from.equals("mumoing@icloud.com"))
            {
       
            pmm = new pine((MimeMessage) message[i]);     
      
           String id= pmm.getMessageId();
            if(find(id))
            {
            insert(id);
            //System.out.println("Message "  + " subject: " + pmm.getSubject());  
            pmm.getMailContent((Part) message[i]);     
            //System.out.println("Message: " + "\r\n"  + pmm.getBodyText()); 
            allweb.add(pmm.getBodyText());
            }
           // pmm.getMailContent((Part) message[i]); 
            //allweb.add(pmm.getBodyText());
           }
        }  
        return allweb; 
    }
     
}
class mythread implements Runnable {
        public void run()
        {
         
           while(true)
           {
               try{
                 List<String> allweb=pine.one_parse();
                 List<String> along=null;
                 for(int i=0;i<allweb.size();i++)
                 {
                     along=parseAll.Huffington(allweb.get(i));
                     word.output(along); 
                 }
                 Thread.sleep(3600000);}
               catch(Exception e)
               {
                   e.printStackTrace();
                }
          }
        }
        
        

         
        
    }